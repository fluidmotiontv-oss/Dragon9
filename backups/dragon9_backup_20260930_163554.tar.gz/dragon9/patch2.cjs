Aesthetic telemetry added.
